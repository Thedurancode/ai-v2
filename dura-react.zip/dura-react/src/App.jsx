import React, { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import styled, { createGlobalStyle, ThemeProvider as StyledThemeProvider } from 'styled-components';
import { useTheme } from './context/ThemeContext';
import { FavoritesProvider } from './context/FavoritesContext';
import { SettingsProvider } from './context/SettingsContext';

// Pages
import HomePage from './pages/HomePage';
import FavoritesPage from './pages/FavoritesPage';
import CurrentPartnersPage from './pages/CurrentPartnersPage';
import PotentialPartnersPage from './pages/PotentialPartnersPage';
import SettingsPage from './pages/SettingsPage';
import Header from './components/Header';

// Global styles
const GlobalStyle = createGlobalStyle`
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  html, body {
    width: 100%;
    overflow-x: hidden;
  }

  body {
    font-family: ${props => props.theme.fonts.primary};
    background-color: ${props => props.theme.colors.background.primary};
    color: ${props => props.theme.colors.text.primary};
    line-height: 1.6;
    min-height: 100vh;
    overflow-x: hidden;
  }

  /* Hide scrollbars while keeping scrolling functionality */
  * {
    scrollbar-width: none; /* Firefox */
    -ms-overflow-style: none; /* IE and Edge */
  }

  *::-webkit-scrollbar {
    display: none; /* Chrome, Safari and Opera */
  }

  a {
    text-decoration: none;
    color: inherit;
  }

  button, input {
    font-family: inherit;
  }

  @media (max-width: 480px) {
    html {
      font-size: 14px;
    }
  }
`;

const AppContainer = styled.div`
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 2.5rem;
  width: 100%;

  @media (max-width: 1200px) {
    max-width: 1200px;
    padding: 0 2rem;
  }

  @media (max-width: 768px) {
    padding: 0 1rem;
    max-width: 100%;
  }

  @media (max-width: 480px) {
    padding: 0 0.5rem;
    max-width: 100%;
  }
`;

const App = () => {
  const theme = useTheme();
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);

  const toggleCompanyHistory = () => {
    setIsHistoryModalOpen(!isHistoryModalOpen);
  };

  return (
    <StyledThemeProvider theme={theme}>
      <FavoritesProvider>
        <SettingsProvider>
          <GlobalStyle />
          <AppContainer>
            <Header toggleCompanyHistory={toggleCompanyHistory} />
            <Routes>
              <Route path="/" element={<HomePage isHistoryModalOpen={isHistoryModalOpen} setIsHistoryModalOpen={setIsHistoryModalOpen} />} />
              <Route path="/favorites" element={<FavoritesPage />} />
              <Route path="/current-partners" element={<CurrentPartnersPage />} />
              <Route path="/potential-partners" element={<PotentialPartnersPage />} />
              <Route path="/settings" element={<SettingsPage />} />
            </Routes>
          </AppContainer>
        </SettingsProvider>
      </FavoritesProvider>
    </StyledThemeProvider>
  );
};

export default App;