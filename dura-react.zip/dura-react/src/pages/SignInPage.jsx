import React from 'react';
import { SignIn } from '@clerk/clerk-react';

const SignInPage = () => {
  console.log('Rendering SignInPage');
  try {
    return (
    <div style={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      minHeight: '100vh',
      width: '100vw',
      backgroundColor: '#121212',
      position: 'fixed',
      top: 0,
      left: 0,
      zIndex: 9999
    }}>
      <div style={{
        width: '100%',
        maxWidth: '420px',
        padding: '2rem',
        backgroundColor: '#1e1e1e',
        borderRadius: '8px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.25)'
      }}>
        <SignIn 
          routing="path" 
          path="/sign-in"
          onError={(error) => console.error('Clerk SignIn error:', error)}
          appearance={{
            elements: {
              rootBox: {
                width: '100%'
              },
              card: {
                backgroundColor: 'transparent',
                boxShadow: 'none',
                width: '100%'
              }
            }
          }}
        />
      </div>
    </div>
    );
  } catch (error) {
    console.error('SignInPage render error:', error);
    return (
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
        backgroundColor: '#121212',
        color: 'white',
        padding: '2rem'
      }}>
        <div>
          <h1>Error Loading Authentication</h1>
          <p>Please check your network connection and refresh the page.</p>
          <p>Error details: {error.message}</p>
        </div>
      </div>
    );
  }
};

export default SignInPage;
